import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from utils import (
    fetch_playlist_names,
    fetch_channels,
    get_channel_logos,
    get_epg_name_map,
    get_epg_programmes,
    match_epg_channel_id,
    get_now_playing,
)

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def build_url(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def get_params():
    paramstring = sys.argv[2][1:]  # rimuove il '?' iniziale
    return dict(urllib.parse.parse_qsl(paramstring))


def show_error(message):
    xbmcgui.Dialog().ok("Errore", message)
    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False)


def list_playlists():
    """Root del plugin: elenca le playlist disponibili su Supabase."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "Playlist")
    xbmcplugin.setContent(ADDON_HANDLE, "files")

    names, err = fetch_playlist_names()
    if err:
        show_error(err)
        return

    for name in names:
        item = xbmcgui.ListItem(label=name)
        item.setArt({"icon": "DefaultPlaylist.png"})
        url = build_url(action="list_channels", playlist=name)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, item, isFolder=True)

    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_channels(playlist_name):
    """Elenca i canali di una playlist, con logo e programma in onda ora
    presi dall'EPG XMLTV (matching per nome canale, non per id esatto:
    i canali su Supabase non hanno un tvg-id, solo un nome libero)."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, playlist_name)
    xbmcplugin.setContent(ADDON_HANDLE, "videos")

    channels, err = fetch_channels(playlist_name)
    if err:
        show_error(err)
        return

    logos = get_channel_logos()
    epg_name_map = get_epg_name_map()
    programmes = get_epg_programmes()

    for ch in channels:
        title = ch.get("title") or ch.get("name") or "Canale Senza Nome"
        stream_url = ch.get("url") or ch.get("link") or ch.get("stream")
        if not stream_url:
            continue

        category = ch.get("category", "Generale")

        epg_id = match_epg_channel_id(title, epg_name_map)
        logo = logos.get(epg_id.strip().lower(), "") if epg_id else ""
        now_playing = get_now_playing(epg_id, programmes) if epg_id else ""

        item = xbmcgui.ListItem(label=title)
        item.setArt({"icon": logo or "DefaultAddonPVRClient.png", "thumb": logo, "fanart": logo})
        video_info = {"title": title, "genre": category}
        if now_playing:
            # Il plot compare come sottotitolo/descrizione sotto il nome
            # canale nelle skin che mostrano info aggiuntive nella lista.
            video_info["plot"] = now_playing
        item.setInfo("video", video_info)
        item.setProperty("IsPlayable", "true")

        _set_inputstream_properties(item, ch, stream_url)

        # L'URL con eventuali header (sintassi url|Header=Value) va nel path
        # del ListItem: e' lo stesso formato che usavi nel KODIPROP m3u.
        url = build_url(action="play", playlist=playlist_name, title=title)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, item, isFolder=False)

    xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def _set_inputstream_properties(item, ch, stream_url):
    """Configura inputstream.adaptive/clearkey sul ListItem, replicando la
    logica gia' presente in generate-m3u (index.ts)."""
    base_url, _, header_string = stream_url.partition("|")
    lower_base = base_url.lower()

    is_mpd = (ch.get("type") or "").lower() == "mpd" or ".mpd" in lower_base
    is_hls = (ch.get("type") or "").lower() == "hls" or ".m3u8" in lower_base
    has_drm = (ch.get("drm") or "").lower() == "clearkey" and bool(ch.get("clearkey_hex"))

    if is_mpd:
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", "mpd")
        if has_drm:
            item.setProperty(
                "inputstream.adaptive.drm_legacy",
                f"org.w3.clearkey|{ch['clearkey_hex']}"
            )
        if header_string:
            item.setProperty("inputstream.adaptive.stream_headers", header_string)
    elif is_hls and not has_drm:
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", "hls")
        if header_string:
            item.setProperty("inputstream.adaptive.stream_headers", header_string)
            # Per playlist HLS "live" (senza master playlist, refresh
            # periodico dell'index) alcune versioni di inputstream.adaptive
            # non riapplicano stream_headers alla richiesta di refresh fatta
            # internamente da OpenStream(); manifest_headers copre proprio
            # quella richiesta.
            item.setProperty("inputstream.adaptive.manifest_headers", header_string)

    item.setPath(stream_url)


def play_channel(playlist_name, title):
    """Ri-recupera il canale (per avere sempre dati freschi) e lo riproduce."""
    channels, err = fetch_channels(playlist_name)
    if err:
        show_error(err)
        return

    channel = next(
        (c for c in channels if (c.get("title") or c.get("name")) == title),
        None
    )
    if channel is None:
        show_error(f"Canale '{title}' non trovato nella playlist.")
        return

    stream_url = channel.get("url") or channel.get("link") or channel.get("stream")
    if not stream_url:
        show_error(f"Nessun URL disponibile per '{title}'.")
        return

    item = xbmcgui.ListItem(label=title, path=stream_url)
    _set_inputstream_properties(item, channel, stream_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, item)


def router():
    params = get_params()
    action = params.get("action")

    if action == "list_channels":
        list_channels(params["playlist"])
    elif action == "play":
        play_channel(params["playlist"], params["title"])
    else:
        list_playlists()


if __name__ == "__main__":
    router()