import json
import os
import re
import difflib
import urllib.request
import urllib.parse
import urllib.error
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
import xbmc
import xbmcvfs
import xbmcaddon

# --- CONFIGURAZIONE SUPABASE ---
SUPABASE_BASE = "https://dyrfzmtsyvvkdgdeelwn.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR5cmZ6bXRzeXZ2a2RnZGVlbHduIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MjY2ODc4OCwiZXhwIjoyMDk4MjQ0Nzg4fQ.2flI9PzfSUf6Ah6kn4G1XZcXZ1oU0EChHiPZUjrHzEA"

EPG_URL = "https://raw.githubusercontent.com/gb7-bit/epg/refs/heads/master/guide.xml"

# File di riferimento con la mappa "nome canale mostrato" -> xmltv_id,
# curata a mano. E' la fonte di verita' per il matching dei nomi: usarla
# al posto (o come priorita' rispetto) del fuzzy-match sui <display-name>
# di guide.xml evita mismatch imprevedibili sui canali esteri (Eurosport,
# VRT, France TV, ecc.) i cui nomi su Supabase non sempre coincidono
# esattamente col display-name dell'EPG.
CHANNELS_REF_URL = "https://raw.githubusercontent.com/gb7-bit/epg/refs/heads/master/miei_canali.xml"

_HEADERS = {
    'User-Agent': 'Kodi-LiveTV-Helper',
    'apikey': SUPABASE_KEY,
    'Authorization': f'Bearer {SUPABASE_KEY}',
    'Accept': 'application/json'
}

# Cache in memoria del solo processo corrente. NOTA: un plugin video Kodi
# (xbmc.python.pluginsource) puo' essere rilanciato come processo Python
# NUOVO ad ogni navigazione (root -> playlist -> canali), quindi questa
# cache in-memory da sola NON basta a evitare fetch ripetuti: e' un
# ottimizzazione per quando il processo viene riutilizzato, ma il vero
# "safety net" e' la cache su disco sotto (_disk_cache_path).
_logo_cache = None

# Cache dei programmi EPG: {channel_id: [(start_dt, stop_dt, title), ...]}
_epg_programmes_cache = None

# Cache del mapping "nome canale normalizzato" -> channel_id XMLTV.
# Costruita PRIMA da miei_canali.xml (fonte di verita' curata a mano),
# poi completata con i <display-name> di guide.xml per gli id non
# presenti in miei_canali.xml.
_epg_name_to_id_cache = None

# TTL della cache su disco: se i dati su disco sono piu' vecchi di questo,
# proviamo comunque a riscaricare, ma se il download fallisce li usiamo
# comunque come fallback (meglio EPG "vecchio" che EPG assente).
_DISK_CACHE_TTL_SECONDS = 6 * 60 * 60  # 6 ore


def _disk_cache_path():
    """Percorso del file di cache EPG persistito su disco, nella cartella
    dati dell'addon (sopravvive tra invocazioni/processi diversi, a
    differenza delle variabili globali in memoria)."""
    profile_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    if not xbmcvfs.exists(profile_path):
        xbmcvfs.mkdirs(profile_path)
    return os.path.join(profile_path, "epg_cache.json")


def _save_disk_cache(logos, name_to_id, programmes):
    """Serializza la cache EPG su disco. I datetime vengono convertiti in
    stringhe ISO per essere JSON-serializzabili."""
    try:
        serializable_programmes = {
            ch_id: [
                [start_dt.isoformat(), stop_dt.isoformat(), title]
                for start_dt, stop_dt, title in slots
            ]
            for ch_id, slots in programmes.items()
        }
        payload = {
            "saved_at": datetime.now(timezone.utc).isoformat(),
            "logos": logos,
            "name_to_id": name_to_id,
            "programmes": serializable_programmes,
        }
        with open(_disk_cache_path(), "w", encoding="utf-8") as f:
            json.dump(payload, f)
    except Exception as e:
        xbmc.log(f"[SupabaseHelper] Impossibile salvare la cache EPG su disco: {str(e)}", xbmc.LOGWARNING)


def _load_disk_cache(ignore_ttl=False):
    """Legge la cache EPG da disco. Ritorna (logos, name_to_id, programmes)
    oppure None se il file non esiste, e' corrotto, o e' scaduto (a meno
    che ignore_ttl=True, usato come ultima spiaggia quando il download
    fallisce e non abbiamo nient'altro)."""
    path = _disk_cache_path()
    try:
        if not xbmcvfs.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        saved_at = datetime.fromisoformat(payload["saved_at"])
        age = (datetime.now(timezone.utc) - saved_at).total_seconds()
        if age > _DISK_CACHE_TTL_SECONDS and not ignore_ttl:
            return None

        programmes = {
            ch_id: [
                (datetime.fromisoformat(s), datetime.fromisoformat(e), title)
                for s, e, title in slots
            ]
            for ch_id, slots in payload["programmes"].items()
        }
        return payload["logos"], payload["name_to_id"], programmes
    except Exception as e:
        xbmc.log(f"[SupabaseHelper] Cache EPG su disco illeggibile/corrotta: {str(e)}", xbmc.LOGWARNING)
        return None


def _http_get_json(url):
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode('utf-8'))


def fetch_playlist_names():
    """Ritorna (lista_nomi, errore)."""
    url = f"{SUPABASE_BASE}/rest/v1/playlists?select=name&order=name.asc"
    try:
        data = _http_get_json(url)
        names = [row["name"] for row in data if row.get("name")]
        if not names:
            return None, "Nessuna playlist trovata su Supabase."
        return names, None
    except urllib.error.HTTPError as e:
        return None, f"Errore Supabase (HTTP {e.code}): {e.reason}"
    except Exception as e:
        return None, f"Errore connessione a Supabase: {str(e)}"


def fetch_channels(playlist_name):
    """Ritorna (lista_canali, errore) per una playlist specifica."""
    url = f"{SUPABASE_BASE}/rest/v1/playlists?name=eq.{urllib.parse.quote(playlist_name)}&select=channels"
    try:
        data = _http_get_json(url)
        if not isinstance(data, list) or len(data) == 0:
            return None, f"Playlist '{playlist_name}' non trovata."
        channels = data[0].get("channels", [])
        if not channels:
            return None, f"La playlist '{playlist_name}' è vuota."
        return channels, None
    except urllib.error.HTTPError as e:
        return None, f"Errore Supabase (HTTP {e.code}): {e.reason}"
    except Exception as e:
        return None, f"Errore connessione a Supabase: {str(e)}"


def _parse_xmltv_datetime(raw):
    """Converte 'YYYYMMDDHHMMSS +ZZZZ' (formato XMLTV) in datetime UTC-aware.
    Ritorna None se il formato non e' quello atteso."""
    if not raw:
        return None
    raw = raw.strip()
    m = re.match(r"^(\d{14})\s*([+-]\d{4})?$", raw)
    if not m:
        return None
    base, offset = m.group(1), m.group(2)
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except ValueError:
        return None
    if offset:
        sign = 1 if offset[0] == "+" else -1
        oh, om = int(offset[1:3]), int(offset[3:5])
        from datetime import timedelta
        dt = dt - sign * timedelta(hours=oh, minutes=om)
    return dt.replace(tzinfo=timezone.utc)


def _normalize_channel_name(name):
    """Normalizza un nome canale per il matching fuzzy: minuscolo, senza
    spazi/simboli/suffissi comuni (HD, +1, Italia...)."""
    if not name:
        return ""
    n = name.lower().strip()
    n = re.sub(r"\b(hd|fhd|uhd|4k|sd)\b", "", n)
    n = re.sub(r"[^a-z0-9]+", "", n)
    return n


def _load_channels_ref():
    """Scarica e parsa miei_canali.xml, ritornando {nome_normalizzato:
    xmltv_id}. Ignora le righe con xmltv_id vuoto (canali senza EPG noto,
    es. RAIPLAY, RAI RADIO 2). Non solleva eccezioni: in caso di errore
    ritorna un dict vuoto e logga un warning, cosi' il resto del flusso
    EPG (loghi/programmi da guide.xml) continua a funzionare comunque."""
    name_to_id = {}
    try:
        req = urllib.request.Request(CHANNELS_REF_URL, headers={'User-Agent': 'Kodi-LiveTV-Helper'})
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read()

        root = ET.fromstring(raw)
        for channel_el in root.findall("channel"):
            xmltv_id = (channel_el.get("xmltv_id") or "").strip()
            if not xmltv_id:
                continue
            display_name = channel_el.text or ""
            norm = _normalize_channel_name(display_name)
            if norm and norm not in name_to_id:
                name_to_id[norm] = xmltv_id

    except Exception as e:
        xbmc.log(f"[SupabaseHelper] Impossibile leggere miei_canali.xml: {str(e)}", xbmc.LOGWARNING)

    return name_to_id


def _load_epg_data(force_reload=False):
    """
    Scarica e parsa miei_canali.xml + guide.xml una volta per sessione.
    Ritorna una tupla (logos, name_to_id, programmes):
      - logos: {channel_id: icon_url}                    (da guide.xml)
      - name_to_id: {nome_normalizzato: channel_id}       (miei_canali.xml
        ha priorita'; i <display-name> di guide.xml completano il resto)
      - programmes: {channel_id: [(start_dt, stop_dt, title), ...]}
    """
    global _logo_cache, _epg_name_to_id_cache, _epg_programmes_cache

    # Livello 1: cache in memoria del processo corrente (utile solo se
    # Kodi riusa lo stesso interprete Python tra due navigazioni).
    if (
        not force_reload
        and _logo_cache is not None
        and _epg_name_to_id_cache is not None
        and _epg_programmes_cache is not None
    ):
        return _logo_cache, _epg_name_to_id_cache, _epg_programmes_cache

    # Livello 2: cache su disco ancora "fresca" (dentro il TTL). Copre il
    # caso, molto comune sui plugin video, in cui ogni navigazione lancia
    # un processo Python NUOVO: qui la cache in memoria (Livello 1) e'
    # sempre vuota, ma quella su disco sopravvive tra un processo e l'altro.
    if not force_reload:
        disk_data = _load_disk_cache()
        if disk_data is not None:
            logos, name_to_id, programmes = disk_data
            _logo_cache, _epg_name_to_id_cache, _epg_programmes_cache = logos, name_to_id, programmes
            return logos, name_to_id, programmes

    # Livello 3: download vero e proprio.
    # Priorita' 1: mapping curato a mano (miei_canali.xml). E' la fonte
    # di verita' per come i nomi vengono effettivamente cercati.
    name_to_id = _load_channels_ref()

    logos, programmes, guide_name_to_id = _load_guide_xml()

    # I nomi da guide.xml completano solo quelli non gia' coperti da
    # miei_canali.xml, cosi' la mappa curata a mano vince sempre.
    for norm, ch_id in guide_name_to_id.items():
        if norm not in name_to_id:
            name_to_id[norm] = ch_id

    guide_fetch_failed = not logos and not programmes and not guide_name_to_id
    if guide_fetch_failed:
        # Livello 4 (fallback finale): il download e' fallito. Prima di
        # arrenderci e mostrare la lista canali senza EPG, proviamo la
        # cache in memoria (se il processo e' stato riusato) e poi quella
        # su disco anche se scaduta (ignore_ttl=True): un EPG "vecchio di
        # qualche ora" e' comunque molto meglio di nessun EPG.
        if _logo_cache is not None:
            xbmc.log(
                "[SupabaseHelper] guide.xml non raggiungibile: mantengo la cache EPG in memoria.",
                xbmc.LOGWARNING,
            )
            return _logo_cache, _epg_name_to_id_cache, _epg_programmes_cache

        stale_disk_data = _load_disk_cache(ignore_ttl=True)
        if stale_disk_data is not None:
            xbmc.log(
                "[SupabaseHelper] guide.xml non raggiungibile: uso la cache EPG su disco (anche se scaduta).",
                xbmc.LOGWARNING,
            )
            logos, name_to_id, programmes = stale_disk_data
            _logo_cache, _epg_name_to_id_cache, _epg_programmes_cache = logos, name_to_id, programmes
            return logos, name_to_id, programmes

        xbmc.log(
            "[SupabaseHelper] guide.xml non raggiungibile e nessuna cache disponibile: EPG assente per questo giro.",
            xbmc.LOGERROR,
        )

    _logo_cache = logos
    _epg_name_to_id_cache = name_to_id
    _epg_programmes_cache = programmes
    _save_disk_cache(logos, name_to_id, programmes)
    return logos, name_to_id, programmes


def _load_guide_xml(retries=2):
    """Scarica e parsa guide.xml. Ritorna (logos, programmes, name_to_id).
    In caso di errore persistente ritorna tre dict vuoti e logga un
    LOGERROR (visibile anche senza debug attivo in Kodi)."""
    logos = {}
    programmes = {}
    name_to_id = {}

    last_error = None
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(EPG_URL, headers={'User-Agent': 'Kodi-LiveTV-Helper'})
            with urllib.request.urlopen(req, timeout=20) as response:
                raw = response.read()

            root = ET.fromstring(raw)

            for channel_el in root.findall("channel"):
                ch_id = channel_el.get("id")
                if not ch_id:
                    continue

                icon_el = channel_el.find("icon")
                if icon_el is not None:
                    src = icon_el.get("src")
                    if src:
                        logos[ch_id.strip().lower()] = src

                for dn_el in channel_el.findall("display-name"):
                    if dn_el.text:
                        norm = _normalize_channel_name(dn_el.text)
                        if norm and norm not in name_to_id:
                            name_to_id[norm] = ch_id

            for prog_el in root.findall("programme"):
                ch_id = prog_el.get("channel")
                if not ch_id:
                    continue
                start_dt = _parse_xmltv_datetime(prog_el.get("start"))
                stop_dt = _parse_xmltv_datetime(prog_el.get("stop"))
                if not start_dt or not stop_dt:
                    continue
                title_el = prog_el.find("title")
                title = title_el.text.strip() if title_el is not None and title_el.text else ""
                if not title:
                    continue
                programmes.setdefault(ch_id, []).append((start_dt, stop_dt, title))

            if attempt > 1:
                xbmc.log(
                    f"[SupabaseHelper] guide.xml letto correttamente al tentativo {attempt}.",
                    xbmc.LOGINFO,
                )
            return logos, programmes, name_to_id

        except Exception as e:
            last_error = e
            xbmc.log(
                f"[SupabaseHelper] Tentativo {attempt}/{retries} fallito per guide.xml: {str(e)}",
                xbmc.LOGWARNING,
            )
            logos, programmes, name_to_id = {}, {}, {}

    xbmc.log(
        f"[SupabaseHelper] Impossibile leggere guide.xml dopo {retries} tentativi: {str(last_error)}",
        xbmc.LOGERROR,
    )
    return {}, {}, {}


def get_channel_logos(force_reload=False):
    """Ritorna {channel_id: icon_url}. Mantenuta per compatibilita' con
    il resto del codice: ora e' un wrapper su _load_epg_data()."""
    logos, _, _ = _load_epg_data(force_reload=force_reload)
    return logos


def get_epg_name_map(force_reload=False):
    """Ritorna {nome_canale_normalizzato: channel_id} per il matching."""
    _, name_to_id, _ = _load_epg_data(force_reload=force_reload)
    return name_to_id


def get_epg_programmes(force_reload=False):
    """Ritorna {channel_id: [(start_dt, stop_dt, title), ...]}."""
    _, _, programmes = _load_epg_data(force_reload=force_reload)
    return programmes


def match_epg_channel_id(title, name_map, cutoff=0.72):
    """Trova il channel_id XMLTV che meglio corrisponde al titolo del
    canale Supabase (es. 'Sky Sport F1' -> 'SkySportF1.it@SD'), usando
    prima un match esatto sul nome normalizzato e poi un fuzzy match
    (difflib, libreria standard, nessuna dipendenza esterna)."""
    if not title or not name_map:
        return None

    norm = _normalize_channel_name(title)
    if not norm:
        return None

    # match esatto (dopo normalizzazione) prima di tutto
    if norm in name_map:
        return name_map[norm]

    # fuzzy match: difflib lavora su sequenze di caratteri, quindi
    # confrontiamo direttamente le stringhe normalizzate
    candidates = list(name_map.keys())
    best = difflib.get_close_matches(norm, candidates, n=1, cutoff=cutoff)
    if best:
        return name_map[best[0]]
    return None


def get_now_playing(channel_id, programmes):
    """Ritorna il titolo del programma attualmente in onda per un dato
    channel_id XMLTV, oppure stringa vuota se non trovato/non disponibile."""
    info = get_now_playing_info(channel_id, programmes)
    return info[0] if info else ""


def get_now_playing_info(channel_id, programmes):
    """Come get_now_playing, ma ritorna (titolo, start_dt, stop_dt) del
    programma in onda ora, oppure None se non trovato/non disponibile.
    Utile quando serve anche l'orario (es. per mostrarlo in lista)."""
    if not channel_id:
        return None
    slots = programmes.get(channel_id)
    if not slots:
        return None

    now = datetime.now(timezone.utc)
    for start_dt, stop_dt, title in slots:
        if start_dt <= now < stop_dt:
            return title, start_dt, stop_dt
    return None


def get_logo_for_channel(title, logos_map):
    """Match case-insensitive tra tvg-id/titolo canale e la mappa loghi XMLTV."""
    if not title:
        return ""
    return logos_map.get(title.strip().lower(), "")