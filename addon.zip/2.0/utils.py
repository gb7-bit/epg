import json
import urllib.request
import urllib.parse
import urllib.error
import xml.etree.ElementTree as ET
import xbmc
import xbmcvfs

# --- CONFIGURAZIONE SUPABASE ---
SUPABASE_BASE = "https://dyrfzmtsyvvkdgdeelwn.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR5cmZ6bXRzeXZ2a2RnZGVlbHduIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MjY2ODc4OCwiZXhwIjoyMDk4MjQ0Nzg4fQ.2flI9PzfSUf6Ah6kn4G1XZcXZ1oU0EChHiPZUjrHzEA"

EPG_URL = "https://raw.githubusercontent.com/gb7-bit/epg/refs/heads/master/guide.xml"

_HEADERS = {
    'User-Agent': 'Kodi-LiveTV-Helper',
    'apikey': SUPABASE_KEY,
    'Authorization': f'Bearer {SUPABASE_KEY}',
    'Accept': 'application/json'
}

# Cache in memoria del solo processo corrente (il plugin viene richiamato
# ad ogni navigazione, quindi non persiste tra una chiamata e l'altra, ma
# evita comunque fetch ripetuti nella stessa sessione di navigazione se il
# modulo resta caricato da Kodi tra invocazioni ravvicinate).
_logo_cache = None


def _http_get_json(url):
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode('utf-8'))


def fetch_playlist_names():
    """Ritorna (lista_nomi, errore)."""
    url = f"{SUPABASE_BASE}/rest/v1/playlists?select=name&order=name.asc"
    try:
        data = _http_get_json(url)
        names = [row["name"] for row in data if row.get("name")]
        if not names:
            return None, "Nessuna playlist trovata su Supabase."
        return names, None
    except urllib.error.HTTPError as e:
        return None, f"Errore Supabase (HTTP {e.code}): {e.reason}"
    except Exception as e:
        return None, f"Errore connessione a Supabase: {str(e)}"


def fetch_channels(playlist_name):
    """Ritorna (lista_canali, errore) per una playlist specifica."""
    url = f"{SUPABASE_BASE}/rest/v1/playlists?name=eq.{urllib.parse.quote(playlist_name)}&select=channels"
    try:
        data = _http_get_json(url)
        if not isinstance(data, list) or len(data) == 0:
            return None, f"Playlist '{playlist_name}' non trovata."
        channels = data[0].get("channels", [])
        if not channels:
            return None, f"La playlist '{playlist_name}' è vuota."
        return channels, None
    except urllib.error.HTTPError as e:
        return None, f"Errore Supabase (HTTP {e.code}): {e.reason}"
    except Exception as e:
        return None, f"Errore connessione a Supabase: {str(e)}"


def get_channel_logos(force_reload=False):
    """
    Scarica e parsa l'XMLTV una volta per sessione e ritorna un dict
    {channel_id: icon_url}. L'XMLTV usa <channel id="..."><icon src=".."/>
    ...</channel>, e i tuoi canali usano tvg-id = title, quindi il match
    è per titolo esatto (case-insensitive) sull'attributo id.
    """
    global _logo_cache
    if _logo_cache is not None and not force_reload:
        return _logo_cache

    logos = {}
    try:
        req = urllib.request.Request(EPG_URL, headers={'User-Agent': 'Kodi-LiveTV-Helper'})
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read()

        root = ET.fromstring(raw)
        for channel_el in root.findall("channel"):
            ch_id = channel_el.get("id")
            icon_el = channel_el.find("icon")
            if ch_id and icon_el is not None:
                src = icon_el.get("src")
                if src:
                    logos[ch_id.strip().lower()] = src
    except Exception as e:
        xbmc.log(f"[SupabaseHelper] Impossibile leggere loghi da EPG: {str(e)}", xbmc.LOGWARNING)

    _logo_cache = logos
    return logos


def get_logo_for_channel(title, logos_map):
    """Match case-insensitive tra tvg-id/titolo canale e la mappa loghi XMLTV."""
    if not title:
        return ""
    return logos_map.get(title.strip().lower(), "")
